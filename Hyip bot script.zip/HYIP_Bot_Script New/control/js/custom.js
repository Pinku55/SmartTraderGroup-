$("#submit_form").on('submit',(function(e) {
	e.preventDefault();
	 $('button[type=submit]', this).attr('disabled', 'disabled');
	$("#msg").html('<div class="alert">Processing....</div>');
	$.ajax({
	url: $("#submit_form").attr("action"), // Url to which the request is send
	type: "POST",             // Type of request to be send, called as method
	data: new FormData(this), // Data sent to server, a set of key/value pairs (i.e. form fields and values)
	contentType: false,       // The content type used when sending data to the server.
	cache: false,             // To unable request pages to be cached
	processData:false,        // To send DOMDocument or non processed data file it is set to false
	success: function(data)   // A function to be called if request succeeds
	{ 
		
		$("#msg").html(data);  
		var res = data.search("alert-success"); 
		$("button[type=submit]").removeAttr('disabled');
 
		 
	}
	});
	}));


function selectSub(datas){
	
	var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (xhttp.readyState == 4 && xhttp.status == 200) { 
	      document.getElementById("sub_cat").innerHTML = xhttp.responseText;
	    }
	  };
	  xhttp.open("POST", "get_subcat.php", true);
	  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	  xhttp.send("catid="+datas);
	
}



function get_subject(val){ 
	
	var depertment = document.getElementById("depertment").value;
	
	var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("subject").innerHTML=xmlhttp.responseText;
	//alert(xmlhttp.responseText);
    }
}
xmlhttp.open("GET","subject.php?dis="+val+"&dept="+depertment,true);
xmlhttp.send();
	
	
	
}