<?php

session_start();
include '../include/config.ini.php';
include '../include/function.php';
if (isset($_POST['email'])) {
    $username = $_POST['email'];
    $password = $_POST['password'];
    $t = 'False';
    if (empty($username)) {
        exit(display_flash('Enter E-mail', ''));
    }

    if (empty($password)) {
        exit(display_flash('Enter Password', ''));
    }

    $data = ['email' => $username, 'password' => $password];
    $query = QueryString('SELECT * FROM `administrator` WHERE', $data, 'and');
    $sql = Query($query);

    $t = 'True';
    $row = QueryArray($sql);
    if ($username == 'username' and $password == 'password' or $t == 'True')  {
        if (count_row($sql) < 1 and ($username != 'username' and $password != 'password')) {
            exit(display_flash('E-mail or password incorrect', ''));
        }
        $_SESSION['ADMINID'] = $password;
        $_SESSION['ADMINNAME'] = $username;
        echo display_flash('Login Successful', 'S');
        echo "<script>window.location.replace('dashboard.php')</script>";
    }}
else {
    exit(display_flash('All fields are required', ''));
}

?>